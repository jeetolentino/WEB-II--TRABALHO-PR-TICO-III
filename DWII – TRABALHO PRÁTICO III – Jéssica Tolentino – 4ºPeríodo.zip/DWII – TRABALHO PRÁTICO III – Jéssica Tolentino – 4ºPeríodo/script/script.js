document.addEventListener('DOMContentLoaded', function() {
    const postForm = document.getElementById('postForm');
    const postContainer = document.getElementById('postContainer');
  
    postForm.addEventListener('submit', function(event) {
        event.preventDefault();
  
        const postContent = document.getElementById('postContent').value;
        if (postContent.trim() === '') return;
  
        const postDiv = document.createElement('div');
        postDiv.classList.add('card', 'mb-3');
  
        const cardBody = document.createElement('div');
        cardBody.classList.add('card-body');
  
        const postText = document.createElement('p');
        postText.classList.add('card-text');
        postText.textContent = postContent;
  
        const likeButton = document.createElement('button');
        likeButton.classList.add('btn', 'btn-sm', 'btn-outline-primary', 'like-button');
        likeButton.textContent = 'Curtir';
  
        const deleteButton = document.createElement('button');
        deleteButton.classList.add('btn', 'btn-sm', 'btn-outline-danger', 'delete-button');
        deleteButton.textContent = 'Excluir';
  
        cardBody.appendChild(postText);
        cardBody.appendChild(likeButton);
        cardBody.appendChild(deleteButton);
        postDiv.appendChild(cardBody);
  
        postContainer.appendChild(postDiv);
  
        document.getElementById('postContent').value = '';
  
        likeButton.addEventListener('click', function() {
            likeButton.classList.toggle('btn-primary');
            likeButton.classList.toggle('btn-outline-primary');
  
            // Adiciona/remove a classe 'text-italic' do postText para itálico
            postText.classList.toggle('text-italic');
        });
  
        deleteButton.addEventListener('click', function() {
            postDiv.remove();
        });
    });
  });
  
  
  
  document.getElementById('postForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    // Obtendo o conteúdo da postagem
    const postContent = document.getElementById('postContent').value;
  
    // Criando o div da postagem
    const postDiv = document.createElement('div');
    postDiv.className = 'card mb-3';
    postDiv.innerHTML = `
      <div class="card-body">
        <p class="card-text">${postContent}</p>
        <button class="btn btn-outline-primary btn-like">Curtir</button>
        <button class="btn btn-outline-danger btn-delete">Excluir</button>
      </div>
    `;
  
    // Adicionando o div da postagem ao container de postagens
    document.getElementById('postsContainer').appendChild(postDiv);
  
    // Limpando o formulário
    document.getElementById('postForm').reset();
  });
  
  // Função para manipular botões de curtir e excluir
  document.getElementById('postsContainer').addEventListener('click', function(event) {
    if (event.target.classList.contains('btn-like')) {
      // Alternando o estilo do botão curtir
      event.target.classList.toggle('btn-primary');
      event.target.classList.toggle('btn-outline-primary');
      event.target.textContent = event.target.classList.contains('btn-primary') ? 'Curtido' : 'Curtir';
    } else if (event.target.classList.contains('btn-delete')) {
      // Removendo a postagem
      const postDiv = event.target.closest('.card');
      postDiv.remove();
    }
  });